<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.header {
  overflow: hidden;
  padding: 10px 10px;
  position: fixed;
  top: 0;
  width: 100%;
  overflow: hidden;
  background-color: #f1f1f1;
}

.header a {
  color: #d9d9d9;
  float: left;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}


  
  .header.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #b3d9ff;
  color: black;
}

.header a.active {
  background-color: #b3d9ff;
  color: white;
}

.header-right {
  float: right;
}

@media screen and (max-width: 600px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
    right: 0;
    top: 0;
  }

  
  .header-right {
    float: none;
  }
}
</style>
</head>
<body>

<div class="header">
  
  <div class="header-right">    
    <a class="active" href="home.php">Types Of Animals</a>
    <a href="upload.php">Upload</a>
  </div>
</div>



</body>
</html>
