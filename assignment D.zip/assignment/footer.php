<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #f2f2f2;
   color: black;
   text-align: center;
}
</style>
</head>
<body>

<div class="footer">

	<?php


try{

  $conn=new PDO("mysql:host=localhost;dbname=animal","root","");

}
catch(PDOExection $e){

  echo $e->getMessage;
}

$sql="update category set visitor_counter=visitor_counter+1";
$stmt=$conn->prepare($sql);
$stmt->execute();
$sql="select visitor_counter from category";
$stmt=$conn->prepare($sql);
$stmt->execute();
$arr=$stmt->fetchAll(PDO::FETCH_ASSOC);
$counter=$arr[0]['visitor_counter'];
$count=strlen($counter);
?>
<style>
  #visitor_counter li{list-style: none;

    float: left;
    background-color: #b5e0fd;
    padding: 1%;
    margin-left: 1%;
    color: black;
    font-size: 20px;
  }

</style>

<div>
  <ul id="visitor_counter">
    <?php for($i=0;$i<$count;$i++){?>
      <li><?php echo $counter[$i]?></li>
    <?php }?>
    
  </ul>
</div>





  <p>Projects By Divyanshu Kumar</p>
</div>




</body>
</html> 
